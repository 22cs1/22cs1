def match(Home, Visitor, matchnum):
      print("Match", str(matchnum))
      scorehome = int(input("Enter the number of points "+Home+" got in Match "+str(matchnum)+": "))
      scorevisitor = int(input("Enter the number of points "+Visitor+" got in  Match "+str(matchnum)+": "))   
      return scorehome, scorevisitor
def printScoreCard(Home,Visitor,winhome,winvisitor):
      print(Home,winhome)
      print(Visitor, winvisitor)
def startgame():
      print("Welcome to the volleyball score program.")
      Home = input("Enter the home team's name: ")
      Visitor = input("Enter the visitor's team name: ")
      winhome = 0
      winvisitor = 0
      for i in range(5):
            scorehome,scorevisitor=match(Home, Visitor,i+1)
            if (scorehome > scorevisitor and scorehome < 25):
                  print("One team must score at least 25 points")
            elif (scorehome > scorevisitor and scorehome - scorevisitor < 2):
                  print("One team must win by 2")
            elif (scorevisitor > scorehome and scorevisitor < 25):
                  print("One team must score at least 25 points")
            elif (scorevisitor > scorehome and scorevisitor - scorehome < 2):
                  print("One team must win by 2")
            elif scorehome > scorevisitor:
                  winhome = winhome + 1
            else:
                  scorevisitor > scorehome
                  winvisitor = winvisitor + 1                                              
            printScoreCard(Home,Visitor,winhome,winvisitor)

      if winhome>winvisitor:
            print(Home+" wins the game!")
      else:
            print(Visitor+" wins the game!")      

startgame()